<?php
session_name("admin_session");
session_start();
require_once 'database.php';

// Restrict access to admins only
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle search input
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchEscaped = $conn->real_escape_string($search);

// SQL with optional search
$query = "
    SELECT 
        p.fullName, p.email, p.phone, 
        a.department, a.appointmentDate, a.appointmentTime, a.amount, a.status 
    FROM 
        appointments a
    JOIN 
        users p ON a.user_id = p.id
";

if (!empty($search)) {
    $query .= " WHERE 
        p.fullName LIKE '%$searchEscaped%' OR 
        p.email LIKE '%$searchEscaped%' OR 
        p.phone LIKE '%$searchEscaped%' OR 
        a.department LIKE '%$searchEscaped%'";
}

$query .= " ORDER BY a.appointmentDate DESC, a.appointmentTime DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin: User Appointments</title>
    <style>
        body {
            font-family: sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 0;
        }

      .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background-color: #007bff;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 15px 30px;
    align-items: center;
    z-index: 1000; /* ensures it stays above everything */
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

        .navbar .logo {
            font-size: 22px;
            font-weight: bold;
        }

        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .navbar .nav-links a:hover {
            text-decoration: underline;
        }

        h2 {
            text-align: center;
            margin: 30px 0 10px;
        }

        form {
            text-align: center;
            margin-bottom: 20px;
        }

        input[type="text"] {
            padding: 8px;
            width: 280px;
        }

        button {
            padding: 8px 12px;
            cursor: pointer;
        }

        table {
            width: 95%;
            margin: 0 auto 40px;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .status {
            font-weight: bold;
        }

        .status.Pending {
            color: orange;
        }

        .status.Paid {
            color: green;
        }

        .status.Cancelled {
            color: red;
        }

        .no-data {
            text-align: center;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div style="height: 70px;"></div>

    <nav class="navbar">
        <div class="logo">+ MASS Admin</div>
        <div class="nav-links">
             <button onclick="window.location.href='admin.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
   </button>
        </div>
    </nav>

    <h2>All Appointments with Patient Info</h2>

    <!-- 🔍 Search form -->
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Search by name, email, phone, or department" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Patient Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Date</th>
                <th>Time</th>
                <th>Amount (TSH)</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['fullName']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= htmlspecialchars($row['appointmentDate']) ?></td>
                        <td><?= htmlspecialchars($row['appointmentTime']) ?></td>
                        <td><?= number_format($row['amount']) ?></td>
                        <td class="status <?= htmlspecialchars($row['status']) ?>">
                            <?= htmlspecialchars($row['status']) ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="8" class="no-data">No appointments found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
