  <nav class="navbar">
    <div class="logo">+ MASS User</div>
    <div id="google_translate_element" style="margin-left: 15px;"></div>

    
    <div class="nav-links">
     <a href="notifications.php" title="Notifications" style="position: relative;">
  🔔
  <span id="notificationBadge"
        style="position: absolute; top: -5px; right: -5px; background: red; color: white; 
               border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;">
  </span>
</a>

    
          <label class="switch" title="Toggle Dark Mode">
        <input type="checkbox" id="darkModeToggle">
        <span class="slider"></span>
      </label>
      <span id="modeLabel" style="margin-left: 8px; color: white; font-size: 14px;">Light Mode</span>
         <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
        <a href="views.php">Your Details</a>
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>
    </div>
</div>
    </div>
  </nav>