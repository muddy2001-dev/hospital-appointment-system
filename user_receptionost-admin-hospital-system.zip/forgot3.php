<?php
session_name("admin_session");
session_start();
include 'database.php';

if (!isset($_SESSION['admin_id'])) {
    die("Please login first.");
}

$admin_id = $_SESSION['admin_id'] ?? null;
$message = "";
$step = "verify"; // default step

// If already verified current password before, skip step
if (!empty($_SESSION['password_verified']) && $_SESSION['password_verified'] === true) {
    $step = "update";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === "verify") {
        $currentPassword = trim($_POST['current_password'] ?? '');

        // Fetch user hash
        $stmt = $conn->prepare("SELECT password FROM admin WHERE id = ?");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $admin = $res->fetch_assoc();
        $stmt->close();

        if (!$admin || !password_verify($currentPassword, $admin['password'])) {
            $message = "<div class='error'>Incorrect current password.</div>";
        } else {
            $_SESSION['password_verified'] = true; // mark verified
            $step = "update"; // go to next step
            $message = "<div style='color:blue;'>Now enter your new password.</div>";
        }
    } elseif ($step === "update") {
        $newPassword    = trim($_POST['new_password'] ?? '');
        $retypePassword = trim($_POST['retype_password'] ?? '');

        if (strlen($newPassword) < 6) {
            $message = "<div class='error'>New password must be at least 6 characters.</div>";
        } elseif ($newPassword !== $retypePassword) {
            $message = "<div class='error'>Passwords do not match.</div>";
        } else {
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $upd = $conn->prepare("UPDATE admin SET password=? WHERE id=?");
            $upd->bind_param("si", $hashed, $admin_id);

            if ($upd->execute()) {
                $message = "<div style='color:green;'>Password updated successfully.</div>";
                unset($_SESSION['password_verified']); // reset flow
                $step = "verify"; // reset back to first step
            } else {
                $message = "<div class='error'>Failed to update password.</div>";
            }
            $upd->close();
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<style>
            
                 .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background-color: #007bff;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 5px 10px;
    align-items: center;
    z-index: 1000; /* stays above other content */
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

        .navbar .logo {
            font-size: 20px;
            font-weight: bold;
        }

        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .navbar .nav-links a:hover {
            text-decoration: underline;
        }
form { max-width:400px; margin:40px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);}
label { display:block; margin:12px 0 6px; font-weight:500; }
input[type=password] { width:100%; padding:10px; border-radius:5px; border:1px solid #ccc; margin-bottom:5px; }
input[type=submit] { background-color:#2c3e50; color:#fff; padding:10px 20px; border:none; border-radius:4px; cursor:pointer; margin-top:7px; }
.error { color:red; font-size:14px; margin-bottom:5px; }
</style>
</head>
<body>
      <nav class="navbar">
    <div class="logo">+ MASS</div>
    <div class="nav-links">
<div class="p">
<button onclick="window.location.href='admin.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
   </button>
</div>
            

    </div>
</nav>
<div class="form-container">
<form method="POST">
    <h2>Change Password</h2>
    <?= $message ?>

    <?php if ($step === "verify"): ?>
        <label>Current Password</label>
        <input type="password" name="current_password" required>
        <input type="submit" value="Verify Current Password">
    <?php elseif ($step === "update"): ?>
        <label>New Password</label>
        <input type="password" name="new_password" required placeholder="Enter new password">

        <label>Retype New Password</label>
        <input type="password" name="retype_password" required placeholder="Retype new password">

        <input type="submit" value="Update Password">
    <?php endif; ?>
</form>
</div>
</body>
</html>
