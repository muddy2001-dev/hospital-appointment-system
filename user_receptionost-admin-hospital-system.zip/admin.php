<?php
session_name("admin_session");
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: admin_login.php");
    exit();
}
$initial = '?';
if (isset($_SESSION['email'])) {
    $initial = strtoupper(substr($_SESSION['email'], 0, 1));
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f7fa;
      padding-top: 40px;
    }

    .navbar {
      background-color: #007bff;
      color: white;
      display: flex;
      justify-content: space-between;
      padding: 1px 5px;
      align-items: center;
        background-color: #007bff;

  position: fixed;  /* <--- add this */
  top: 0;           /* <--- add this */
  left: 0;
  right: 0;
  z-index: 1000;    /* <--- add this */
}
    

    .navbar .logo {
      font-size: 22px;
      font-weight: bold;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .nav-links a {
      color: white;
      text-decoration: none;
    }

    .nav-links a:hover {
      text-decoration: underline;
    }

    .profile-circle {
      width: 15px;
      height: 15px;
      background-color: black;
      color: #007bff;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
      text-decoration: none;
      margin-left: auto;
      border: 2px solid #007bff;
      user-select: none;
      transition: background-color 0.3s, color 0.3s;
    }

    .profile-circle:hover {
      background-color: #007bff;
      color: white;
    }

    h2 {
      text-align: center;
      margin: 30px 0 10px;
      color: #333;
    }

    .dashboard-cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      max-width: 1000px;
      margin: 0 auto;
      gap: 20px;
      padding: 20px;
    }

    .card-link {
      flex: 1 1 calc(33% - 20px);
      text-decoration: none;
    }

    .card {
      background-color: white;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      text-align: center;
      transition: transform 0.2s;
      border: 1px solid #e0e0e0;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    .card strong {
      display: block;
      margin-top: 8px;
      font-size: 18px;
      color: #333;
    }

    .card-logo {
      font-size: 36px;
    }

    @media (max-width: 768px) {
      .card-link {
        flex: 1 1 100%;
      }
    }

    /* Dark mode support */
    body.dark-mode {
      background-color: #121212;
      color: #f0f0f0;
    }

    body.dark-mode .navbar {
      background-color: #1e1e1e;
    }

    body.dark-mode .card {
      background-color: #1f1f1f;
      border: 1px solid #444;
    }

    body.dark-mode .card strong,
    body.dark-mode h2 {
      color: #f0f0f0;
    }

    body.dark-mode .nav-links a,
    body.dark-mode .profile-circle,
    body.dark-mode #modeLabel {
      color: #f0f0f0;
    }

    .switch {
      position: relative;
      display: inline-block;
      width: 50px;
      height: 26px;
      margin-left: 15px;
    }

    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      background-color: #ccc;
      border-radius: 34px;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      border-radius: 50%;
      background-color: white;
      left: 3px;
      bottom: 3px;
      transition: .4s;
    }

    input:checked + .slider {
      background-color: #2196F3;
    }

    input:checked + .slider:before {
      transform: translateX(24px);
    }
    .profile-dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0; /* align to right edge of profile */
    background-color: blue;
    min-width: 140px;
    box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
    border-radius: 6px;
    z-index: 1000;
    margin-top: 8px;
}

.dropdown-content a {
    color: #333;
    padding: 5px 10px;
    text-decoration: none;
    display: block;
    font-size: 14px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
}

.dropdown-content a:last-child {
    border-bottom: none;
}

.dropdown-content a:hover {
    background-color: #007bff;
 
}

/* Show dropdown when active */
.profile-dropdown.show .dropdown-content {
    display: block;
}
footer {
      text-align: center;
      padding: 15px 10px;
      font-size: 14px;
      color: white;
      border-top: 1px solid #ddd;
     background-color: #007bff;
      margin-top: 30px;
    }

    body.dark-mode footer {
      color: #bbb;
      border-top: 1px solid #444;
      background-color: #1e1e1e;
    }
  </style>
</head>
<body>
  <nav class="navbar">
    <div class="logo">+ MASS Admin</div>
    <div class="nav-links">
    <a href="notifictions.php" title="Notifications" style="position: relative;">
  🔔
  <span id="notificationBadge"
        style="position: absolute; top: -5px; right: -5px; background: red; color: white; 
               border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;">
  </span>
</a>

    
          <label class="switch" title="Toggle Dark Mode">
        <input type="checkbox" id="darkModeToggle">
        <span class="slider"></span>
      </label>
      <span id="modeLabel" style="margin-left: 8px; color: white; font-size: 14px;">Light Mode</span>
         <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
        <a href="views_admin.php">Your Details</a>
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>
    </div>
</div>
    </div>
  </nav>
<script>
document.addEventListener("DOMContentLoaded", function () {
  fetch('get_admin_unread_notifications.php')
    .then(response => response.json())
    .then(data => {
      const badge = document.getElementById('notificationBadge');
      if (data.count > 0) {
        badge.innerText = data.count;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    fetch("get_admin_unread_notifications.php")
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById("notificationBadge");
            if (data.count > 0) {
                badge.innerText = data.count;
                badge.style.display = "inline-block";
            } else {
                badge.style.display = "none";
            }
        })
        .catch(error => console.error("Error loading notifications:", error));
});
</script>
  <h2>Welcome, Admin</h2>

  <div class="dashboard-cards">
    <a href="manage_slots.php" class="card-link">
      <div class="card">
        <div class="card-logo">📅</div>
        <strong>Manage Appointments</strong>
      </div>
    </a>
        <a href="view_users.php" class="card-link">
      <div class="card">
        <div class="card-logo">👥</div>
        <strong>View Appointments</strong>
      </div>
    </a>


 <a href="signup_users.php" class="card-link">
  <div class="card">
    <div class="card-logo">🧾</div>
    <strong>Registered Users</strong>
  </div>
</a>

<a href="manage_users.php" class="card-link">
  <div class="card">
    <div class="card-logo">👤</div>
    <strong>Manage Users</strong>
  </div>
</a>

<a href="view_walk_in.php" class="card-link">
  <div class="card">
    <div class="card-logo">🚶‍♂️</div>
    <strong>Manage Walk-In Patients</strong>
  </div>
</a>

<a href="dep.php" class="card-link">
  <div class="card">
    <div class="card-logo">🏢</div>
    <strong>Manage Departments</strong>
  </div>
</a>


      <a href="update_admin.php" class="card-link">
      <div class="card">
        <div class="card-logo">⚙️</div>
        <strong>Settings</strong>
      </div>
    </a>

    <a href="admin_msg.php" class="card-link">
      <div class="card">
      <div class="card-logo">💬</div>
<strong>Messages</strong>
      </div>
    </a>
       <a href="booking_report.php" class="card-link">
      <div class="card">
        <div class="card-logo">📊</div>
        <strong>Reports</strong>
      </div>
    </a>
  </div>
<footer>
  &copy; <?= date('Y') ?> MASS Admin Dashboard. All rights reserved. |
 
  <br><a href="admin_faq.php" style="color: white; text-decoration: none;">FAQs</a>
</footer>

  <script>
    function confirmLogout() {
      if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout_admin.php";
      }
    }

    const toggle = document.getElementById('darkModeToggle');
    const label = document.getElementById('modeLabel');

    document.addEventListener('DOMContentLoaded', function () {
      if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
        toggle.checked = true;
        label.textContent = 'Dark Mode';
      }
    });

    toggle.addEventListener('change', function () {
      document.body.classList.toggle('dark-mode');
      const mode = document.body.classList.contains('dark-mode');
      localStorage.setItem('darkMode', mode);
      label.textContent = mode ? 'Dark Mode' : 'Light Mode';
    });
  </script>
  <script>
function updateNotificationBadge() {
  fetch('unread.php')
    .then(response => response.json())
    .then(data => {
      const badge = document.getElementById('notificationBadge');
      if (data.count > 0) {
        badge.textContent = data.count;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    });
}

// Run on page load
updateNotificationBadge();

// Optionally: update every 10 seconds
setInterval(updateNotificationBadge, 10000);
</script>
</script>
<script>document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.getElementById('profileBtn');
    const profileMenu = document.getElementById('profileMenu');
    const profileDropdown = profileBtn.parentElement;

    profileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        profileDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', function(e) {
        if (!profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('show');
        }
    });
});
</script>
</body>
</html>
