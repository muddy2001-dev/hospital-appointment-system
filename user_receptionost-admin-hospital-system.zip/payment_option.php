<?php
// Start session or retrieve booking data if needed
session_start();

// Optional: Store booking data in session for later processing
$_SESSION['booking_data'] = $_POST ?? [];

?>

<!DOCTYPE html>
<html>
<head>
    <title>Select Payment Option</title>
    <style>
      body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fa;
        }

        .navbar {
            background-color: #007bff;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
            align-items: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }
        .container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        h2 {
            margin-bottom: 25px;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
        .btn-warning {
            background-color: #ffc107;
            color: black;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .warning {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
            color: #856404;
        }
    </style>
      <?php require_once 'darkmode.php'; ?>
</head>
<body>
      <nav class="navbar">
        <div class="logo">+ MASS</div>
        <div class="nav-links">
            <button onclick="window.location.href='index.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
   </button>
          
        </div>
    </nav>
<div class="container">
    <h2>Choose Payment Option</h2>
    
    <form method="post" action="payment_choice.php">
        <input type="submit" name="choice" value="Pay Now" class="btn">
        <input type="submit" name="choice" value="Pay Later" class="btn btn-warning">
    </form>
</div>
</body>
</html>
