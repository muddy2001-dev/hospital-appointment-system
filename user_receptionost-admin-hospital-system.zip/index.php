<?php
session_name("user_session");
session_start();

if (!isset($_SESSION['user_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: login.php");
    exit();
}

$initial = '?';

// Always read from user_email
if (!empty($_SESSION['user_email'])) {
    $initial = strtoupper(substr($_SESSION['user_email'], 0, 1));
}
?>

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="styles.css">

<script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en',
    includedLanguages: 'en,sw',
    layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL
  }, 'google_translate_element');
}
</script>


<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f7fa;
      padding-top: 40px;
    }

    .navbar {
      
      background-color: #007bff;
      color: white;
      display: flex;
      justify-content: space-between;
      padding: 1px 5px;
      align-items: center;
        background-color: #007bff;

  position: fixed;  /* <--- add this */
  top: 0;           /* <--- add this */
  left: 0;
  right: 0;
  z-index: 1000;    /* <--- add this */
}
    

    .navbar .logo {
      font-size: 22px;
      font-weight: bold;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .nav-links a {
      color: white;
      text-decoration: none;
    }

    .nav-links a:hover {
      text-decoration: underline;
    }

    .profile-circle {
      width: 15px;
      height: 15px;
      background-color: red;
      color: #007bff;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      cursor: pointer;
      text-decoration: none;
      margin-left: auto;
      border: 2px solid #007bff;
      user-select: none;
      transition: background-color 0.3s, color 0.3s;
    }

    .profile-circle:hover {
      background-color: #007bff;
      color: white;
    }

        .profile-dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0; /* align to right edge of profile */
    background-color: blue;
    min-width: 140px;
    box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
    border-radius: 6px;
    z-index: 1000;
    margin-top: 8px;
}

.dropdown-content a {
    color: #333;
    padding: 5px 10px;
    text-decoration: none;
    display: block;
    font-size: 14px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
}

.dropdown-content a:last-child {
    border-bottom: none;
}

.dropdown-content a:hover {
    background-color: #007bff;
 
}

/* Show dropdown when active */
.profile-dropdown.show .dropdown-content {
    display: block;
}

    h2 {
      text-align: center;
      margin: 30px 0 10px;
      color: #333;
    }

    .dashboard-cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      max-width: 1000px;
      margin: 0 auto;
      gap: 35px;
      padding: 20px;
    }

    .card-link {
      flex: 1 1 calc(33% - 20px);
      text-decoration: none;
    }

  .card {
  background-color: white;
  border-radius: 10px;
  padding: 30px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  text-align: center;
  transition: transform 0.2s;
  border: 1px solid #e0e0e0;
  min-height: 140px; /* <-- Add this line */
}


    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    .card strong {
      display: block;
      margin-top: 8px;
      font-size: 18px;
      color: #333;
    }

    .card-logo {
      font-size: 36px;
    }

    @media (max-width: 768px) {
      .card-link {
        flex: 1 1 100%;
      }
    }

    /* Dark mode support */
    body.dark-mode {
      background-color: #121212;
      color: #f0f0f0;
    }

    body.dark-mode .navbar {
      background-color: #1e1e1e;
    }

    body.dark-mode .card {
      background-color: #1f1f1f;
      border: 1px solid #444;
    }

    body.dark-mode .card strong,
    body.dark-mode h2 {
      color: #f0f0f0;
    }

    body.dark-mode .nav-links a,
    body.dark-mode .profile-circle,
    body.dark-mode #modeLabel {
      color: #f0f0f0;
    }

    .switch {
      position: relative;
      display: inline-block;
      width: 50px;
      height: 26px;
      margin-left: 15px;
    }

    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      background-color: #ccc;
      border-radius: 34px;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 20px;
      width: 20px;
      border-radius: 50%;
      background-color: white;
      left: 3px;
      bottom: 3px;
      transition: .4s;
    }

    input:checked + .slider {
      background-color: #2196F3;
    }

    input:checked + .slider:before {
      transform: translateX(24px);
    }


.footer {
  background-color:blue;
  color: #ffffff;
  font-family: 'Segoe UI', sans-serif;
  padding: 40px 20px;
}

.footer-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 30px;
}

.footer-column {
  flex: 1 1 250px;
}

.footer-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.logo-icon {
  background-color: #ffffff;
  color: #0f3d57;
  font-weight: bold;
  padding: 5px 10px;
  border-radius: 50%;
  font-size: 20px;
}

.footer-column h2 {
  margin: 0;
}

.footer-column h3 {
  margin-bottom: 10px;
  font-size: 18px;
  border-bottom: 1px solid #ffffff30;
  padding-bottom: 5px;
}

.footer-column p,
.footer-column ul,
.footer-column li {
  margin: 5px 0;
}

.footer-column ul {
  list-style: none;
  padding: 0;
}

.footer-column ul li a {
  color: #ffffff;
  text-decoration: none;
}

.footer-column ul li a:hover {
  text-decoration: underline;
}

.footer-bottom {
  width: 100%;
  display: block;
  text-align: center;
  /* your existing styles */
}



.social-icons i {
  margin: 0 10px;
  cursor: pointer;
  font-size: 18px;
  color: #ffffff;
}

.social-icons i:hover {
  color: #00aced;
}


    body.dark-mode footer {
      color: #bbb;
      border-top: 1px solid #444;
      background-color: #1e1e1e;
    }
/* === Existing styles above === */

/* Hide large Google Translate top banner and skip translate elements */
.goog-te-banner-frame.skiptranslate,
body > .skiptranslate,
iframe.goog-te-banner-frame {
  display: none !important;
  height: 0 !important;
  visibility: hidden !important;
}

body {
  top: 0px !important;
}

/* Hide Google logo and "Powered by" text */
.goog-logo-link,
.goog-te-gadget span {
  display: none !important;
}

/* Style the language dropdown */
.goog-te-combo {
  font-size: 14px !important;
  padding: 5px 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  background-color: white;
  color: #333;
  cursor: pointer;
  margin-left: 8px;
  min-width: 90px; /* optional to keep width consistent */
}

/* Hover effect on dropdown */
.goog-te-combo:hover {
  border-color: #007bff;
}

/* Ensure the translate element container stays on top */
#google_translate_element {
  position: relative;
  z-index: 1000;
}

/* Optional: add icon spacing in navbar */
#google_translate_element_wrapper i {
  margin-right: 6px;
  color: white;
  font-size: 16px;
  user-select: none;
}

/* === Other existing styles below === */

  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <nav class="navbar">
    <marquee></marquee>
    <div class="logo"><marquee>User Dashboard</marquee></div>
    <div id="google_translate_element" style="margin-left: 15px;"></div>

    
    <div class="nav-links">
     <a href="notifications.php" title="Notifications" style="position: relative;">
  🔔
  <span id="notificationBadge"
        style="position: absolute; top: -5px; right: -5px; background: red; color: white; 
               border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;">
  </span>
</a>

    
          <label class="switch" title="Toggle Dark Mode">
        <input type="checkbox" id="darkModeToggle">
        <span class="slider"></span>
      </label>
      <span id="modeLabel" style="margin-left: 8px; color: white; font-size: 14px;">Light Mode</span>
         <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
        <a href="views.php">Your Details</a>
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>
    </div>
</div>
    </div>
  </nav>

<script>
document.addEventListener("DOMContentLoaded", function () {
    fetch("get_unread_notifications.php")
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById("notificationBadge");
            if (data.count > 0) {
                badge.innerText = data.count;
                badge.style.display = "inline-block";
            } else {
                badge.style.display = "none";
            }
        })
        .catch(error => console.error("Error loading notifications:", error));
});
</script>


    <h2>Welcome to Your Dashboard</h2>

    <div class="dashboard-cards">
        <a href="payment_option.php" class="card-link">
            <div class="card">
                <div class="card-logo">📝</div>
                <strong>Book Appointment</strong>
            </div>
        </a>

        <a href="appointments.php" class="card-link">
            <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>My Appointments</strong>
            </div>
        </a>

        <a href="payments.php" class="card-link">
            <div class="card">
                <div class="card-logo">💳</div>
                <strong>My Payments</strong>
            </div>
        </a>

        <a href="update.php" class="card-link">
            <div class="card">
                <div class="card-logo">⚙️</div>
                <strong>Settings</strong>
            </div>
        </a>
         <a href="reschedule.php" class="card-link">
    <div class="card">
        <div class="card-logo">🔄</div>
        <strong>Reschedule</strong>
    </div>
</a>
    <a href="view_slots.php" class="card-link">
    <div class="card">
        <div class="card-logo">🕒</div>
        <strong>This week</strong>
    </div>
</a>

    </div>
    <script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>

    <script>
const toggle = document.getElementById('darkModeToggle');
const label = document.getElementById('modeLabel');

document.addEventListener('DOMContentLoaded', function () {
  if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
    toggle.checked = true;
    label.textContent = 'Dark Mode';
  }
});

toggle.addEventListener('change', function () {
  document.body.classList.toggle('dark-mode');
  const mode = document.body.classList.contains('dark-mode');
  localStorage.setItem('darkMode', mode);
  label.textContent = mode ? 'Dark Mode' : 'Light Mode';
});
</script>
<script>document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.getElementById('profileBtn');
    const profileMenu = document.getElementById('profileMenu');
    const profileDropdown = profileBtn.parentElement;

    profileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        profileDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', function(e) {
        if (!profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('show');
        }
    });
});
</script>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-column">
      <div class="footer-logo">
      
        <div>
                </div>
      </div>
       <h3>JK Hospital</h3>
          
      <p><i class="fa fa-map-marker"></i>Mikadi ,Kigamboni, Dar es Salaam, Tanzania</p>
      <p><i class="fa fa-phone"></i> 0678101010</p>
      <p><i class="fa fa-envelope"></i> www.jkhospital.or.tz</p>
    </div>

    <div class="footer-column">
      <h3>Quick Links</h3>
      <ul>
       
        <li><a href="about_us.php">About Us</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="faq.php">FAQs</a>
</li>
      </ul>
    </div>

   <div class="footer-column">
  <h3>Hours <i class="fa fa-clock-o"></i></h3>
  <p><strong>Open 24/7</strong><br> Including weekends and public holidays</p>
</div>


  <div class="footer-column">
    <h3>Social Media</h3>
  <div class="social-icons">
  <a href="https://www.facebook.com/yourpage" target="_blank" title="Facebook">
    <i class="fa fa-facebook"></i>
  </a>
  <a href="https://www.twitter.com/yourhandle" target="_blank" title="Twitter">
    <i class="fa fa-twitter"></i>
  </a>
  <a href="https://www.instagram.com/yourprofile" target="_blank" title="Instagram">
    <i class="fa fa-instagram"></i>
  </a>
  <a href="https://www.linkedin.com/company/yourcompany" target="_blank" title="LinkedIn">
    <i class="fa fa-linkedin"></i>
  </a>
  
</div>

   
  </div>
<div class="footer-bottom">
  &copy; 2025 JK Hospital. All rights reserved.
</div>


</footer>


</body>
</html>
