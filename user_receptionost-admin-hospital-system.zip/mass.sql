-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2025 at 02:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mass`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullName`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`) VALUES
(12, 'Ali Rashid Hamad', 'admin@example.com', '0736754357', '$2y$10$DXOQs9RLWTuvTX//Iel3/ewEpDBZ6GyLKrLZ4zRD9c3dycs/cSImK', '', '2025-09-19 12:21:10', 0, '2025-09-19 12:21:10');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `appointmentDate` date NOT NULL,
  `appointmentTime` time NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('Pending','Confirmed','Cancelled','Completed') DEFAULT NULL,
  `slot_id` int(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `department_id` int(11) DEFAULT NULL,
  `booking_method` enum('pay_now','pay_later') DEFAULT 'pay_later',
  `user_hidden` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `user_id`, `department`, `appointmentDate`, `appointmentTime`, `amount`, `status`, `slot_id`, `created_at`, `updated_at`, `department_id`, `booking_method`, `user_hidden`) VALUES
(1, 1, 'Cardiology', '2025-09-18', '00:00:00', 20000.00, 'Completed', 0, '2025-09-18 11:10:40', '2025-09-18 12:19:29', 9, 'pay_now', 0),
(2, 1, 'Cardiology', '2025-09-19', '00:00:00', NULL, 'Pending', 4, '2025-09-18 12:11:20', '2025-09-18 12:12:15', 9, 'pay_later', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(9, 'Cardiology'),
(8, 'General Medicine'),
(11, 'pressure');

-- --------------------------------------------------------

--
-- Table structure for table `department_slots`
--

CREATE TABLE `department_slots` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `slot_date` date NOT NULL,
  `slot_time` time NOT NULL,
  `is_booked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_slots`
--

INSERT INTO `department_slots` (`id`, `department_id`, `slot_date`, `slot_time`, `is_booked`) VALUES
(2, 9, '2025-09-19', '00:00:00', 0),
(3, 9, '2025-09-20', '00:00:00', 0),
(4, 9, '2025-09-18', '00:30:00', 1),
(5, 9, '2025-09-19', '00:30:00', 0),
(6, 9, '2025-09-20', '00:30:00', 0),
(7, 9, '2025-09-18', '01:00:00', 0),
(8, 9, '2025-09-19', '01:00:00', 0),
(9, 9, '2025-09-20', '01:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`) VALUES
(4, 'How do I book an appointment?', 'Login to your account, go to the Book Appointment section, select your preferred department, date, and available time slot, then confirm your appointment.', '2025-06-14 19:39:53'),
(5, 'Can I reschedule my appointment?', 'Yes. Go to My Appointments, and if the status is Pending or Confirmed, you can click Reschedule and choose a new date and time.', '2025-06-14 19:40:27'),
(6, 'How do I cancel an appointment?', 'If your appointment is still Pending, you will see a Cancel button in the My Appointments section. Once cancelled, the appointment cannot be reactivated.', '2025-06-14 19:41:01'),
(7, 'What if I miss my appointment?', 'If you miss an appointment, the system will still mark it as Confirmed and you can reshedulle it again.', '2025-06-14 19:44:16'),
(8, 'How can I make a payment?', 'After booking, go to My Appointments, find the appointment with Pending status, and click Make Payment. Fill in your card or mobile money details to confirm payment.', '2025-06-14 19:44:51'),
(9, 'What happens after I make a payment?', 'Once payment is successful, your appointment status will change to Confirmed, and you\'ll be expected to attend at the scheduled date and time.', '2025-06-14 19:45:26'),
(10, 'Why is my appointment showing “Cancelled”?', 'Appointments can be cancelled manually by the user or automatically by the system if not confirmed within 30 minutes after booking. You’ll need to book again.', '2025-06-14 19:46:05'),
(11, 'How can I view my appointment history?', 'Go to the My Appointments page. All your past and upcoming appointments will be listed there, including status and payment details.', '2025-06-14 19:47:21'),
(12, 'Why can’t I cancel a “Completed” appointment?', 'Once an appointment is marked as Completed by the receptionist, no further actions (like cancellation or rescheduling) can be taken.', '2025-06-14 19:47:57'),
(13, 'Why am I seeing the message “You have already booked an appointment within the last 6 hours. Please wait before booking again”?', 'This message appears when you choose the “Pay Later” option and already have an existing appointment booked within the last 6 hours.\r\nTo ensure fairness and prevent misuse of the Pay Later feature, our system restricts multiple bookings within a 6-hour period under this option.\r\n\r\nIf you want to book another appointment urgently, please:\r\n\r\nWait 6 hours before booking again with Pay Later, or\r\n\r\nUse the Pay Now option to proceed with your next booking.', '2025-06-15 14:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-09-18 11:48:48'),
(2, 1, 'Your appointment for Cardiology on 2025-09-18 at 00:00:00 has been booked successfully.', 1, '2025-09-18 12:10:40'),
(3, 1, 'Your appointment for Cardiology on 2025-09-18 at 00:30:00 has been booked.', 0, '2025-09-18 12:11:20'),
(4, 1, 'Your appointment for Cardiology on 2025-09-18 at 00:30:00 has been rescheduled to 2025-09-19 at 00:00:00.', 0, '2025-09-18 12:12:15'),
(5, 1, 'Your details have been updated successfully on 2025-09-18 14:13:21.', 0, '2025-09-18 12:13:21');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `method` varchar(20) DEFAULT NULL,
  `card_number` varchar(25) DEFAULT NULL,
  `expiry` varchar(7) DEFAULT NULL,
  `cvc` varchar(5) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `appointment_id`, `method`, `card_number`, `expiry`, `cvc`, `amount`, `status`, `created_at`) VALUES
(1, 177, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-18 16:39:06'),
(2, 178, 'debit', '**** 3456', NULL, NULL, 10000, 'Confirmed', '2025-06-18 16:41:07'),
(3, 179, 'credit', '**** 3456', NULL, NULL, 10000, 'Confirmed', '2025-06-18 16:42:50'),
(4, 179, 'credit', '**** 3456', NULL, NULL, 10000, 'Paid', '2025-06-18 16:43:41'),
(5, 179, 'credit', '**** 3456', NULL, NULL, 10000, 'Paid', '2025-06-18 16:47:55'),
(6, 180, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-18 16:58:11'),
(7, 181, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-18 17:04:23'),
(8, 182, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-18 17:11:29'),
(9, 183, 'credit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-18 17:21:21'),
(10, 184, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-20 14:05:16'),
(11, 186, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-20 14:07:21'),
(12, 188, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-20 14:08:54'),
(13, 190, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-06-20 14:11:47'),
(14, 191, 'debit', '**** 3456', NULL, NULL, 10000, 'Paid', '2025-06-20 14:39:20'),
(15, 192, 'debit', '**** 3456', NULL, NULL, 10000, 'Paid', '2025-06-20 16:49:54'),
(16, 196, 'debit', '**** 3456', NULL, NULL, 20000, 'Paid', '2025-08-21 10:14:21'),
(17, 1, 'debit', '**** 3242', NULL, NULL, 20000, 'Paid', '2025-09-18 14:10:40');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_blocked` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`id`, `fullName`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`, `is_blocked`) VALUES
(13, 'Salim Said Ali', 'rec@example.com', '0736754357', '$2y$10$BPiR9EX/qHAHugTUJZPhI.FxNLNBvXZSUtoaQ9T.6mzGscK7gBUZm', '', '2025-09-19 12:03:47', 0, '2025-09-19 12:03:47', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recnotifications`
--

CREATE TABLE `recnotifications` (
  `id` int(11) NOT NULL,
  `receptionist_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `seen` tinyint(1) DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_blocked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`, `is_blocked`) VALUES
(1, 'Ali Rashid Hamad', 'user@example.com', '0736754356', '$2y$10$977Q47n60ZN4RS74rySmQeBUaK7K01zONeuhgQayliG4ozsbvslWm', '233918', '2025-09-19 11:51:14', 0, '2025-09-18 11:48:48', 0);

-- --------------------------------------------------------

--
-- Table structure for table `walkin_patients`
--

CREATE TABLE `walkin_patients` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `payment` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `walkin_patients`
--

INSERT INTO `walkin_patients` (`id`, `fullName`, `phone`, `department`, `payment`, `created_at`) VALUES
(1, 'Ali Rashid Hamad', '0736754357', 'Eye', 20000.00, '2025-09-18 12:19:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_booking` (`department_id`,`appointmentDate`,`appointmentTime`),
  ADD KEY `patient_id` (`user_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `department_slots`
--
ALTER TABLE `department_slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `recnotifications`
--
ALTER TABLE `recnotifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `walkin_patients`
--
ALTER TABLE `walkin_patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `department_slots`
--
ALTER TABLE `department_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `recnotifications`
--
ALTER TABLE `recnotifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `walkin_patients`
--
ALTER TABLE `walkin_patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
